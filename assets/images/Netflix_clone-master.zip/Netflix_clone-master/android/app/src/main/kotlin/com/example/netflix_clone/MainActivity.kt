package com.example.netflix_clone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
