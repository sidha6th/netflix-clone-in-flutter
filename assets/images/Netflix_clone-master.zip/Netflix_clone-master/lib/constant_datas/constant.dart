class Constant {
  String api_key = "3e801f599186241c08d9adfa803d6fd0";
  String baseurl =
      "http://api.themoviedb.org/3/movie/top_rated?api_key=3e801f599186241c08d9adfa803d6fd0&language=en-US&page=1";
  String popular =
      "https://api.themoviedb.org/3/movie/popular?api_key=3e801f599186241c08d9adfa803d6fd0&language=en-US&page=1";
  String upcoming =
      "https://api.themoviedb.org/3/movie/upcoming?api_key=3e801f599186241c08d9adfa803d6fd0&language=en-US&page=1";
  String search =
      "https://api.themoviedb.org/3/movie/top_rated?api_key=3e801f599186241c08d9adfa803d6fd0&language=en-US&page=1";
  String searchKey =
      "https://api.themoviedb.org/3/search/movie?api_key=3e801f599186241c08d9adfa803d6fd0&language=en-US&page=1&include_adult=true";
}
